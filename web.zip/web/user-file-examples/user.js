// Example event listener.
// Event argument will always be {eventType, args} dict

EventHandler.registerCallback(IBOM_EVENT_TYPES.ALL, (e) => console.log(e));
